EaglerCreate asset subset from Create revision 588124239141029c5321afd38d20c2eaf872b32b.
Contains 29 PNG textures and 41 JSON models, plus water wheel OBJ/MTL files.
This is the subset used by EaglerCreate, not all Minecraft or Create assets.
Minecraft host textures and sounds are not included. See CREATE-ASSET-LICENSE.txt.
